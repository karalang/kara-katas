rm -rf ~
